from JoKeRUB import BOTLOG, BOTLOG_CHATID, l313l
from l313l.razan.resources.assistant import *
from ..Config import Config
from ..core.inlinebot import *
